
% gisette_scale data can be downloaded from https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/


[y,X]=libsvmread('gisette_scale');
X = X'; 
y = y';
[d,n]=size(X);
lss=1; eta0 = 0.01; w0 = zeros(1,d); D0 = 10; t=10; K=5;
b=2; gamm=0.01; dlta=1; epsilon=1; dense=1; prox=0; evalk=1;
idx=randsample(n, 1e8, true);
%ASSG
[Obj,it,avgw]=ASSG(X, y, lss, eta0, w0, D0, t,K,b,gamm,dlta,epsilon,dense,prox,idx,evalk);

%RASSG
t=100; K=10; maxt=1000; Tmax=10000; incr=2; reNum=2; reseta=1;
[Obj,it,avgw]=RASSG(X, y, lss, eta0, w0, D0, t,K,b,gamm,dlta,epsilon,dense,prox,idx,maxt,Tmax, incr,reNum, reseta);


