 
 function w = map(w0,D,w,ind)
 % mapping function: Pi_{w,D}(v)
 % ind = find(w0);
 dirt = w;
 dirt(ind) = dirt(ind)-w0(ind);
 d = norm(dirt,2);
 if d > D
     w = w0 + (D/d)*dirt;
 end
 